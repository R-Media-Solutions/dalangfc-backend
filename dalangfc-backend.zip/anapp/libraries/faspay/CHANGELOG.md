# Changelog

All notable changes to this project will be documented in this file.

## [1.0] - 2020-01-01

### Added

- Initiate SendMe Lib