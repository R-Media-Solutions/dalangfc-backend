<?php
/*
* Get credential in your inbox mail from email by faspay
* Version 1.0
*/


$param["development"]["host"] 				= "https://sendme-sandbox.faspay.co.id";
$param["development"]["virtual_account"] 	= "9920001189";
$param["development"]["faspay_key"] 		= "c2b21b0e-e988-4fc8-ae31-39d7177a7186";
$param["development"]["faspay_secret"] 		= "19c887a3-49af-4087-8e82-58a1875b1452";
$param["development"]["app_key"]			= "055061d5-626a-420b-8e1a-dbd6772fd5f6";
$param["development"]["app_secret"] 		= "60d5ce04-b077-44c5-b5b8-6ceeeab11e18";
$param["development"]["client_key"] 		= "571f97de-3216-4598-a80c-240e6d571000";
$param["development"]["client_secret"] 		= "3155e4cb-58af-46c7-b1df-86cd54809672";
$param["development"]["iv"]					= "faspay2018xAuth@#";

$param["production"]["host"] 				= "https://sendme.faspay.co.id";
$param["production"]["virtual_account"] 	= "9920001189";
$param["production"]["faspay_key"]			= "c2b21b0e-e988-4fc8-ae31-39d7177a7186";
$param["production"]["faspay_secret"] 		= "19c887a3-49af-4087-8e82-58a1875b1452";
$param["production"]["app_key"]				= "055061d5-626a-420b-8e1a-dbd6772fd5f6";
$param["production"]["app_secret"]			= "60d5ce04-b077-44c5-b5b8-6ceeeab11e18";
$param["production"]["client_key"]			= "571f97de-3216-4598-a80c-240e6d571000";
$param["production"]["client_secret"] 		= "3155e4cb-58af-46c7-b1df-86cd54809672";
$param["production"]["iv"]					= "faspay2018xAuth@#";

return $param; 