<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-20 10:18:04 --> The upload path does not appear to be valid.
ERROR - 2023-09-20 11:12:13 --> The upload path does not appear to be valid.
ERROR - 2023-09-20 11:13:41 --> The upload path does not appear to be valid.
ERROR - 2023-09-20 11:16:22 --> The upload path does not appear to be valid.
ERROR - 2023-09-20 11:18:40 --> The upload path does not appear to be valid.
ERROR - 2023-09-20 11:21:10 --> The upload path does not appear to be valid.
ERROR - 2023-09-20 11:22:39 --> The upload path does not appear to be valid.
ERROR - 2023-09-20 11:23:11 --> The upload path does not appear to be valid.
