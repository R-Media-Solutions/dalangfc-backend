<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Public_Controller Class
 * 
 * May be used as the parent of order controllers 
 * or any front end public pages controllers
 */
class Public_Controller extends AN_Controller {
	
	function __construct() {
		parent::__construct();
	}

	// --------------------------------------------------------------------
}
